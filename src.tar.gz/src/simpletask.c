#include <stdio.h>
#include <stdint.h>
#include "common.h"

static uint32_t count=0;
void TaskCounter(void)
{
if(count!=0)
{ 
 printf("The counter is %d\n",(unsigned int) count); 
count--;
}
}

void CmdCount(int mode)
{
int rc;
uint32_t value = 0;
  if(mode != CMD_INTERACTIVE)
 {
    return;
  }
rc = fetch_uint32_arg(&value);
if(rc)
{
printf(" Enter value");
return;
}
else
count=value;
  }
ADD_CMD("count",CmdCount," Counting downwards");

